
<div class="cx-opts-onesecond">
	<h3 class="cx-lead"><?php _e( 'Recent Activity', $this->textdomain ); ?></h3>
	
</div>

<div class="cx-opts-onethird">
	<div class="postbox">
		<h3 class="hndle"><?php _e( 'Feedback', $this->textdomain ); ?></h3>

		<div class="inside">
			<p>Help us to improve the plugin.</p>
			<p>
				<a href="#" class="button"><strong>Feedback</strong></a>  &nbsp; 
				<a href="#" class="button">Report bug</a>
			</p>
		</div>
	</div>
</div>
<div class="cx-opts-clear"></div>