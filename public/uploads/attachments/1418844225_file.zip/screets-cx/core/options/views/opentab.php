<div class="cx-opts-pane hide-if-js">
	<table class="form-table">